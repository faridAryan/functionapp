const { app } = require('@azure/functions');
const {Pool} = require('pg')



app.serviceBusQueue('injestor', {
    connection: 'ServiceBusConnection',
    queueName: 'ServiceBusQueue',
    sqlconnection:'PostgreSQLConnectionString',
    handler: async (message, context) =>  {
        const pool = new Pool(sqlconnection);
        try{
            client = await pool.connect();
            console.log('connected');
        }catch(e){

        }
        context.log('Service bus queue function processed message:', message);
        context.log('Service bus queue Name:', queueName);
        context.log('EnqueuedTimeUtc =', context.triggerMetadata.enqueuedTimeUtc);
        context.log('DeliveryCount =', context.triggerMetadata.deliveryCount);
        context.log('MessageId =', context.triggerMetadata.messageId);
    }

});