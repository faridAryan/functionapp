const { app } = require('@azure/functions');

app.http('apiTest', {
    methods: ['GET', 'POST'],
    authLevel: 'anonymous',
    handler: async (request, context) => {
        context.log(`Http function processed request for url "${request.url}"`);

       

        return { body: 'Api is Working' };
    }
});
